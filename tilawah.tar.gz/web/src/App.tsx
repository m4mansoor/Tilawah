import { useEffect, useState, type FormEvent } from "react";
import type { Coverage, QariProfile, Selection } from "./types";
import { api, clearToken, getToken, setToken } from "./api";
import { Crescent, HeroBanner } from "./Art";
import { BookIcon, HeadphonesIcon, MicIcon, ShieldIcon } from "./icons";
import { DailyVerseCard, HadithCard, LeaderboardCard, PrayerTimesCard } from "./widgets";
import { BrowseView, MyView, ReciteView } from "./ReciteView";
import { AdminView } from "./AdminView";
import { AssignmentsView } from "./AssignmentsView";
import { getLang, setLang, t, type Lang } from "./i18n";

type View =
  | "loading"
  | "auth"
  | "onboarding"
  | "home"
  | "recite"
  | "browse"
  | "my"
  | "assignments"
  | "admin";

export default function App() {
  const [view, setView] = useState<View>("loading");
  const [profile, setProfile] = useState<QariProfile | null>(null);
  const [selection, setSelection] = useState<Selection | null>(null);
  const [lang, setLangState] = useState<Lang>(getLang());
  const [coverage, setCoverage] = useState<Coverage | null>(null);

  useEffect(() => {
    (async () => {
      if (!getToken()) {
        setView("auth");
        return;
      }
      try {
        const p = await api.getProfile();
        setProfile(p);
        setView(p.consent_ok ? "home" : "onboarding");
      } catch {
        clearToken();
        setView("auth");
      }
    })();
  }, []);

  async function refreshCoverage() {
    try {
      setCoverage(await api.coverage());
    } catch {
      /* ignore */
    }
  }

  async function afterAuth() {
    const p = await api.getProfile();
    setProfile(p);
    setView(p.consent_ok ? "home" : "onboarding");
  }

  function logout() {
    clearToken();
    setProfile(null);
    setView("auth");
  }

  function goRecite(s: Selection) {
    setSelection(s);
    setView("recite");
  }

  function toggleLang() {
    const next: Lang = lang === "en" ? "ar" : "en";
    setLang(next);
    setLangState(next);
  }

  if (view === "loading") {
    return (
      <main className="wrap narrow">
        <div className="spinner" />
        <p className="center">{t("app.loading")}</p>
      </main>
    );
  }

  if (view === "auth") return <AuthView onAuthed={afterAuth} />;

  if (view === "onboarding" && profile) {
    return (
      <OnboardingView
        profile={profile}
        onDone={(p) => {
          setProfile(p);
          setView("home");
        }}
      />
    );
  }

  if (view === "recite" && selection) {
    return (
      <ReciteView
        selection={selection}
        onDone={() => {
          setSelection(null);
          setView("home");
          refreshCoverage();
        }}
      />
    );
  }

  if (view === "browse") {
    return <BrowseView onPick={goRecite} onBack={() => setView("home")} />;
  }

  if (view === "my") return <MyView onBack={() => setView("home")} />;

  if (view === "assignments") {
    return <AssignmentsView onRecite={goRecite} onBack={() => setView("home")} />;
  }

  if (view === "admin" && profile?.role === "admin") {
    return <AdminView onBack={() => setView("home")} />;
  }

  return (
    <HomeView
      profile={profile!}
      coverage={coverage}
      onCoverage={refreshCoverage}
      onReciteNext={async () => {
        const v = await api.nextVerse();
        goRecite({
          scope: "ayah",
          surah: v.surah,
          ayah: v.ayah,
          juz: null,
          text: v.text,
          label: `${v.surah}:${v.ayah}`,
        });
      }}
      onBrowse={() => setView("browse")}
      onMy={() => setView("my")}
      onAssignments={() => setView("assignments")}
      onAdmin={() => setView("admin")}
      onLogout={logout}
      onToggleLang={toggleLang}
      lang={lang}
    />
  );
}

function AuthView({ onAuthed }: { onAuthed: () => Promise<void> }) {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const res =
        mode === "login"
          ? await api.login(email, password)
          : await api.register(email, password, name || undefined);
      setToken(res.access_token);
      await onAuthed();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <HeroBanner />
      <main className="wrap narrow">
        <p className="tagline">{t("auth.tagline")}</p>
        <form onSubmit={submit} className="card">
        {mode === "register" && (
          <label>
            {t("auth.name")}
            <input value={name} onChange={(e) => setName(e.target.value)} />
          </label>
        )}
        <label>
          {t("auth.email")}
          <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
        </label>
        <label>
          {t("auth.password")}
          <input type="password" required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} />
        </label>
        {error && <p className="error">{error}</p>}
        <button className="primary" disabled={busy}>
          {busy ? t("auth.pleaseWait") : mode === "login" ? t("auth.login") : t("auth.register")}
        </button>
      </form>
      <p className="muted">
        {mode === "login" ? `${t("auth.newHere")} ` : `${t("auth.haveAccount")} `}
        <button className="link" onClick={() => setMode(mode === "login" ? "register" : "login")}>
          {mode === "login" ? t("auth.register") : t("auth.login")}
        </button>
      </p>
      </main>
    </>
  );
}

function OnboardingView({
  profile,
  onDone,
}: {
  profile: QariProfile;
  onDone: (p: QariProfile) => void;
}) {
  const [name, setName] = useState(profile.name ?? "");
  const [gender, setGender] = useState(profile.gender ?? "");
  const [ageRange, setAgeRange] = useState(profile.age_range ?? "");
  const [level, setLevel] = useState(profile.tajweed_level ?? "");
  const [consent, setConsent] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (!consent) {
      setError(t("onboarding.consentError"));
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const p = await api.updateProfile({
        name,
        qiraah: "hafs",
        gender: gender || null,
        age_range: ageRange || null,
        tajweed_level: level || null,
        consent_ok: true,
      });
      onDone(p);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <HeroBanner />
      <main className="wrap narrow">
        <h1>{t("onboarding.welcome")}, {profile.name || profile.email}</h1>
        <p className="tagline">{t("onboarding.sub")}</p>
        <form onSubmit={submit} className="card">
        <label>
          {t("auth.name")}
          <input value={name} onChange={(e) => setName(e.target.value)} />
        </label>
        <label>
          {t("onboarding.qiraah")}
          <input value="Hafs 'an 'Asim" disabled />
        </label>
        <label>
          {t("onboarding.gender")}
          <select value={gender} onChange={(e) => setGender(e.target.value)}>
            <option value="">{t("onboarding.preferNo")}</option>
            <option value="male">{t("onboarding.male")}</option>
            <option value="female">{t("onboarding.female")}</option>
          </select>
        </label>
        <label>
          {t("onboarding.ageRange")}
          <select value={ageRange} onChange={(e) => setAgeRange(e.target.value)}>
            <option value="">{t("onboarding.preferNo")}</option>
            <option value="under18">{t("onboarding.under18")}</option>
            <option value="18-30">18-30</option>
            <option value="31-50">31-50</option>
            <option value="51+">51+</option>
          </select>
        </label>
        <label>
          {t("onboarding.tajweed")}
          <select value={level} onChange={(e) => setLevel(e.target.value)}>
            <option value="">{t("onboarding.select")}</option>
            <option value="beginner">{t("onboarding.beginner")}</option>
            <option value="intermediate">{t("onboarding.intermediate")}</option>
            <option value="advanced">{t("onboarding.advanced")}</option>
          </select>
        </label>
        <label className="check">
          <input type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} />
          <span>{t("onboarding.consent")}</span>
        </label>
        {error && <p className="error">{error}</p>}
        <button className="primary" disabled={busy}>
          {busy ? t("onboarding.save") : t("home.start")}
        </button>
      </form>
      </main>
    </>
  );
}

function HomeView(props: {
  profile: QariProfile;
  coverage: Coverage | null;
  onCoverage: () => Promise<void>;
  onReciteNext: () => Promise<void>;
  onBrowse: () => void;
  onMy: () => void;
  onAssignments: () => void;
  onAdmin: () => void;
  onLogout: () => void;
  onToggleLang: () => void;
  lang: Lang;
}) {
  const { profile, coverage, onCoverage, onReciteNext, onBrowse, onMy, onAssignments, onAdmin, onLogout, onToggleLang, lang } = props;
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    onCoverage();
  }, [onCoverage]);

  async function reciteNext() {
    setBusy(true);
    try {
      await onReciteNext();
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="wrap">
      <header className="topbar appbar">
        <Crescent size={28} />
        <h1 className="brand">تِلاوَة</h1>
        <nav className="nav">
          <button className="nav-link" onClick={onBrowse}>
            <BookIcon size={16} /> {t("nav.browse")}
          </button>
          <button className="nav-link" onClick={onMy}>
            <HeadphonesIcon size={16} /> {t("nav.recordings")}
          </button>
          <button className="nav-link" onClick={onAssignments}>
            {t("nav.assignments")}
          </button>
          {profile.role === "admin" && (
            <button className="nav-link" onClick={onAdmin}>
              <ShieldIcon size={16} /> {t("nav.admin")}
            </button>
          )}
        </nav>
        <div className="spacer" />
        <button className="lang-btn" onClick={onToggleLang}>
          {lang === "en" ? "عربي" : "EN"}
        </button>
        <span className="muted user">{profile.name || profile.email}</span>
        <span className="points-badge">⭐ {profile.points} · 🔥 {profile.streak}</span>
        <button className="link" onClick={onLogout}>{t("nav.logout")}</button>
      </header>

      <section className="home-banner animate-in">
        <img src="/img/blue-mosque.jpg" alt="" />
        <div className="home-banner-overlay">
          <div>
            <div className="home-greeting">{t("home.greeting")}, {profile.name || "Qari"}</div>
            <div className="home-sub">{t("home.sub")}</div>
          </div>
        </div>
      </section>

      <button className="primary big cta-recite animate-in d1" onClick={reciteNext} disabled={busy}>
        <MicIcon size={22} />
        <span>{busy ? t("home.finding") : t("home.start")}</span>
      </button>

      <div className="home-grid">
        <div className="home-main">
          {coverage && (
            <section className="card progress-card animate-in d2">
              <div className="progress-head">
                <h2>{t("home.progress")}</h2>
                <span className="progress-pct">
                  {Math.round((coverage.covered_ayahs / coverage.total_ayahs) * 100)}%
                </span>
              </div>
              <div className="bar">
                <div
                  className="bar-fill"
                  style={{ width: `${Math.min(100, (coverage.covered_ayahs / coverage.total_ayahs) * 100)}%` }}
                />
              </div>
              <div className="stat-row">
                <Stat label={t("stat.approved")} value={coverage.approved_samples} />
                <Stat label={t("stat.covered")} value={`${coverage.covered_ayahs} / ${coverage.total_ayahs}`} />
                <Stat label={t("stat.complete")} value={coverage.complete_ayahs} />
                <Stat label={t("stat.target")} value={`${coverage.target_per_ayah} qaris`} />
              </div>
            </section>
          )}
        </div>
        <aside className="home-side animate-in d2">
          <LeaderboardCard />
          <DailyVerseCard />
          <HadithCard />
          <PrayerTimesCard />
        </aside>
      </div>

      <footer className="footer">{t("footer.tagline")}</footer>
    </main>
  );
}

function Stat({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="stat">
      <div className="stat-value">{value}</div>
      <div className="stat-label">{label}</div>
    </div>
  );
}


