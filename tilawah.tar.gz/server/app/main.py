"""Tilawah correction API (FastAPI)."""
from __future__ import annotations

import base64
import logging
import os
import secrets
import subprocess
import uuid
from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session

from .asr import transcribe
from .auth import get_current_user
from .config import settings
from .db import Base, engine, get_db
from .mail import send_email
from .migrate import run_migrations, seed_admin_users
from .models import User  # noqa: F401  (registers table metadata)
from .quran_data import all_ayahs, get_ayah, get_ayah_by_id
from .ratelimit import limiter
from .schemas import (
    CorrectionRequest,
    CorrectionResponse,
    ForgotPasswordRequest,
    LoginRequest,
    ResetPasswordRequest,
    Token,
    UserCreate,
    UserOut,
    VerifyEmailRequest,
)
from .security import create_access_token, hash_password, verify_password
from .tajweed import diff_words
from .tajweed_rules import detect_tajweed
from .trainer import router as trainer_router
from .verse_match import find_best_reference

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    run_migrations()
    seed_admin_users()
    yield


app = FastAPI(title=settings.app_name, version=settings.version, lifespan=lifespan)

# The React frontend doubles as the web platform, so the API is CORS-enabled.
app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in settings.cors_origins.split(",") if o.strip()],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(trainer_router)


@app.middleware("http")
async def rate_limit_middleware(request: Request, call_next):
    if request.url.path in {"/v1/correct", "/v1/recitations"}:
        limiter.check(request.client.host if request.client else "unknown")
    return await call_next(request)


@app.get("/health")
def health() -> dict:
    """Liveness/readiness probe. Does NOT load the model (keeps startup fast)."""
    return {"status": "ok", "app": settings.app_name, "model": settings.model_id}


@app.post("/v1/auth/register", response_model=Token, status_code=201)
def register(req: UserCreate, db: Session = Depends(get_db)):
    if db.query(User).filter(User.email == req.email).first():
        raise HTTPException(status_code=400, detail="Email already registered")
    token = secrets.token_urlsafe(24)
    user = User(
        email=req.email,
        name=req.name,
        password_hash=hash_password(req.password),
        email_token=token,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    send_email(
        user.email,
        "Verify your Tilawah account",
        f"Verify your email: {settings.app_base_url}/v1/auth/verify-email?token={token}",
    )
    return Token(access_token=create_access_token(user.email))


@app.post("/v1/auth/verify-email")
def verify_email(req: VerifyEmailRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email_token == req.token).first()
    if user is None:
        raise HTTPException(status_code=400, detail="Invalid or expired token")
    user.email_verified = True
    user.email_token = None
    db.commit()
    return {"status": "ok", "message": "Email verified"}


@app.post("/v1/auth/forgot-password")
def forgot_password(req: ForgotPasswordRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == req.email).first()
    if user is not None:
        token = secrets.token_urlsafe(24)
        user.email_token = token
        db.commit()
        send_email(
            user.email,
            "Reset your Tilawah password",
            f"Reset your password: {settings.app_base_url}/v1/auth/reset-password?token={token}",
        )
    # Do not reveal whether the email exists.
    return {"status": "ok", "message": "If the email exists, a reset link was sent"}


@app.post("/v1/auth/reset-password")
def reset_password(req: ResetPasswordRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email_token == req.token).first()
    if user is None:
        raise HTTPException(status_code=400, detail="Invalid or expired token")
    user.password_hash = hash_password(req.password)
    user.email_token = None
    db.commit()
    return {"status": "ok", "message": "Password reset"}


@app.post("/v1/auth/login", response_model=Token)
def login(req: LoginRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == req.email).first()
    if not user or not verify_password(req.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    return Token(access_token=create_access_token(user.email))


@app.get("/v1/auth/me", response_model=UserOut)
def me(user: User = Depends(get_current_user)):
    return user


def _audio_to_file(req: CorrectionRequest) -> str:
    """Save the request audio and convert it to 16 kHz mono WAV via ffmpeg.

    Browsers record WebM/Opus (MediaRecorder), which the ASR model can't always
    decode reliably. Converting to a standard WAV makes transcription robust.
    """
    os.makedirs(settings.tmp_dir, exist_ok=True)
    raw_path = os.path.join(settings.tmp_dir, f"{uuid.uuid4().hex}.raw")
    wav_path = os.path.join(settings.tmp_dir, f"{uuid.uuid4().hex}.wav")

    if req.audio_base64:
        with open(raw_path, "wb") as f:
            f.write(base64.b64decode(req.audio_base64))
    elif req.audio_url:
        # Wired in the platform phase: audio stored on the VPS's local disk
        # (served by the API), referenced by URL.
        raise HTTPException(status_code=501, detail="audio_url download not yet wired")
    else:
        raise HTTPException(status_code=400, detail="Provide audio_base64 or audio_url")

    try:
        subprocess.run(
            ["ffmpeg", "-y", "-i", raw_path, "-ar", "16000", "-ac", "1", wav_path],
            check=True,
            capture_output=True,
        )
    except subprocess.CalledProcessError as exc:
        raise HTTPException(
            status_code=400,
            detail=f"Audio decoding failed: {exc.stderr.decode(errors='ignore')[:200]}",
        )
    finally:
        try:
            os.remove(raw_path)
        except OSError:
            pass
    return wav_path


@app.post("/v1/correct", response_model=CorrectionResponse)
def correct(req: CorrectionRequest) -> CorrectionResponse:
    """Transcribe a recitation and diff it against the reference ayah."""
    audio_path = _audio_to_file(req)
    try:
        transcript = transcribe(audio_path)
    finally:
        try:
            os.remove(audio_path)
        except OSError:
            pass

    logger.info(
        "Transcript (%d words): %r", len(transcript.split()), transcript[:200]
    )

    # Resolve the reference ayah (by explicit id/surah, else fuzzy-match).
    reference = None
    if req.surah and req.ayah:
        reference = get_ayah(req.surah, req.ayah)
    elif req.ayah_id is not None:
        reference = get_ayah_by_id(req.ayah_id)

    if reference is None:
        reference = find_best_reference(transcript, all_ayahs())

    reference_text = reference["text"] if reference else None
    ayah_id = reference["id"] if reference else req.ayah_id
    errors = diff_words(reference_text, transcript) if reference_text else []
    tajweed = detect_tajweed(reference_text) if reference_text else []

    note = None
    if reference is None:
        note = (
            "Couldn't confidently match your recitation to a specific verse. "
            "Try reciting a complete verse slowly and clearly."
        )

    return CorrectionResponse(
        status="ok",
        transcript=transcript,
        ayah_id=ayah_id,
        matched_ayah_text=reference_text,
        note=note,
        errors=errors,
        tajweed=tajweed,
    )
